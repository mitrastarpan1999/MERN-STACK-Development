let array = [1,2,3,4,1,5,2,3,6,9,1]
let unique = []
for (let i = 0 ; i<array.length; i++){
    if(!unique.includes(array[i])){
        unique.push(array[i])
    }
}

console.log(unique);
