const dataList = [];

class card {
  constructor(dataObject) {
    this.dataObject = dataObject;
  }

  cardData() {
    console.log(this.dataObject);
    dataList.push(this.dataObject);

    return dataList;
  }
}

function cardRender(event) {
  event.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const image = document.getElementById("image").value;
  const course = document.getElementById("course").value;

  const showCard = new card({
    name: name,
    email: email,
    phone: phone,
    url: image,
    course: course,
  });

  console.log(showCard.cardData());
  document.getElementById("cardContainer").innerHTML = "";

  for (let i = 0; i < dataList.length; i++) {
    document.getElementById("cardContainer").innerHTML += `<div id="card">
            <img src= ${dataList[i].url} alt="profileimg">
            <p>Name: ${dataList[i].name}</p>
            <p>${dataList[i].phone}</p>
            <p>${dataList[i].email}</p>
            <p>${dataList[i].course}</p>
        </div>`;
  }
}
